function getLatest() {
    return "0.1.0";
}

function getReleases() {return ["0.1.0",];
}

export {
    getLatest, getReleases
}